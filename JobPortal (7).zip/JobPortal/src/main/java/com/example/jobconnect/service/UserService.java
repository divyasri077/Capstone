package com.example.jobconnect.service;

import com.example.jobconnect.dto.UserDto;
import com.example.jobconnect.exception.UserNotFoundException;
import com.example.jobconnect.model.User;
import com.example.jobconnect.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Get all users (Return UserDto)
    public List<UserDto> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(this::convertToDto)  // Convert each User entity to UserDto
                .collect(Collectors.toList());
    }

    // Get user by ID (Return UserDto)
    public UserDto getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));

        return convertToDto(user);
    }

    // Create a new user using UserDto
    public UserDto createUser(UserDto userDto) {
        validateUserDto(userDto);  // Validate the incoming UserDto
        User user = convertToEntity(userDto);  // Convert UserDto to User entity
        user.setCreatedAt(LocalDateTime.now());  // Set timestamps
        user.setUpdatedAt(LocalDateTime.now());

        User savedUser = userRepository.save(user);
        return convertToDto(savedUser);  // Convert back to UserDto for response
    }

    // Update a user using UserDto
    public UserDto updateUser(Long id, UserDto userDto) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));

        validateUserDto(userDto);  // Validate the incoming UserDto

        // Update user fields
        existingUser.setUsername(userDto.getUsername());
        existingUser.setPassword(userDto.getPassword());
        existingUser.setEmail(userDto.getEmail());
        existingUser.setFirstName(userDto.getFirstName());
        existingUser.setLastName(userDto.getLastName());
        existingUser.setProfilePicture(userDto.getProfilePicture());
        existingUser.setUserType(userDto.getUserType());
        existingUser.setUpdatedAt(LocalDateTime.now());  // Update timestamp

        User updatedUser = userRepository.save(existingUser);
        return convertToDto(updatedUser);  // Return updated UserDto
    }

    // Delete a user by ID
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new UserNotFoundException("User not found with id: " + id);
        }
        userRepository.deleteById(id);
    }

    // Validate UserDto
    private void validateUserDto(UserDto userDto) {
        if (!StringUtils.hasText(userDto.getUsername())) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (!StringUtils.hasText(userDto.getPassword())) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        if (!StringUtils.hasText(userDto.getEmail())) {
            throw new IllegalArgumentException("Email cannot be null or empty");
        }
        if (userDto.getPassword().length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long");
        }
        if (!userDto.getEmail().contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    // Convert User entity to UserDto
    private UserDto convertToDto(User user) {
        UserDto userDto = new UserDto();
        userDto.setUserId(user.getUserId());
        userDto.setUsername(user.getUsername());
        userDto.setPassword(user.getPassword());
        userDto.setEmail(user.getEmail());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setProfilePicture(user.getProfilePicture());
        userDto.setUserType(user.getUserType());
     //   userDto.setCreatedAt(user.getCreatedAt());
     //   userDto.setUpdatedAt(user.getUpdatedAt());

        return userDto;
    }

    // Convert UserDto to User entity
    private User convertToEntity(UserDto userDto) {
        User user = new User();
        user.setUsername(userDto.getUsername());
        user.setPassword(userDto.getPassword());
        user.setEmail(userDto.getEmail());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setProfilePicture(userDto.getProfilePicture());
        user.setUserType(userDto.getUserType());

        return user;
    }
}
