package com.example.jobconnect.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications")
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

  /*  // Many applications can be associated with one job
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private JobPosting job; 

    // Many applications can be associated with one job seeker (User)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_seeker_id", nullable = false)
    private User jobSeeker; */
    
    @Lob
    @Column(name = "resume", columnDefinition = "BLOB")
    @NotBlank(message = "Resume cannot be blank")
    private byte[] resume;
    
    @Lob
    @Column(name = "cover_letter", columnDefinition = "BLOB")
    @NotBlank(message = "Cover letter cannot be blank")
    private byte[] coverLetter;

    @NotBlank(message = "Application status cannot be blank")
    private String applicationStatus; // Applied, Interview Scheduled, Rejected, Accepted

    @Column(name = "applied_at")
    private LocalDateTime appliedAt;

    // Getters and Setters

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

  /*  public JobPosting getJob() {
        return job;
    }

    public void setJob(JobPosting job) {
        this.job = job;
    }

    public User getJobSeeker() {
        return jobSeeker;
    }                                 

    public void setJobSeeker(User jobSeeker) {
        this.jobSeeker = jobSeeker;
    } */

    public byte[] getResume() {
        return resume;
    }

    public void setResume(byte[] resume) {
        this.resume = resume;
    }

    public byte[] getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(byte[] coverLetter) {
        this.coverLetter = coverLetter;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public LocalDateTime getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(LocalDateTime appliedAt) {
        this.appliedAt = appliedAt;
    }
}
