package com.example.jobposting.client;

import com.example.jobconnect.model.User; // Adjust the import according to your project structure
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "http://localhost:9090") // Adjust URL and name as needed
public interface UserFeignClient {

    @GetMapping("/users/{id}")
    User getUserById(@PathVariable("id") Long id);
}
