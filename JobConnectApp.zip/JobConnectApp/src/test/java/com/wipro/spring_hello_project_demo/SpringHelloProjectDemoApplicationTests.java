package com.wipro.spring_hello_project_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHelloProjectDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
