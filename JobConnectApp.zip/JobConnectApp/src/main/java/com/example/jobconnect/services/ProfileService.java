package com.example.jobconnect.services;

import com.example.jobconnect.entities.Profile;
import com.example.jobconnect.repositories.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    public List<Profile> getAllProfiles() {
        return profileRepository.findAll();
    }

    public Optional<Profile> getProfileById(Long profileId) {
        return profileRepository.findById(profileId);
    }

    public Profile createProfile(Profile profile) {
        return profileRepository.save(profile);
    }

    public Profile updateProfile(Long profileId, Profile updatedProfile) {
        return profileRepository.findById(profileId)
                .map(prof -> {
                    prof.setBio(updatedProfile.getBio());
                    prof.setSkills(updatedProfile.getSkills());
                    prof.setExperience(updatedProfile.getExperience());
                    prof.setEducation(updatedProfile.getEducation());
                    prof.setLinkedinProfile(updatedProfile.getLinkedinProfile());
                    prof.setWebsite(updatedProfile.getWebsite());
                    return profileRepository.save(prof);
                }).orElseThrow(() -> new RuntimeException("Profile not found"));
    }

    public void deleteProfile(Long profileId) {
        profileRepository.deleteById(profileId);
    }
}
