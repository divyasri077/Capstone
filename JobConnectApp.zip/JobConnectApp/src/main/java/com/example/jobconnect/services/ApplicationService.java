package com.example.jobconnect.services;

import com.example.jobconnect.entities.Application;
import com.example.jobconnect.repositories.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    public Optional<Application> getApplicationById(Long applicationId) {
        return applicationRepository.findById(applicationId);
    }

    public Application createApplication(Application application) {
        return applicationRepository.save(application);
    }

    public Application updateApplication(Long applicationId, Application updatedApplication) {
        return applicationRepository.findById(applicationId)
                .map(app -> {
                    app.setResume(updatedApplication.getResume());
                    app.setCoverLetter(updatedApplication.getCoverLetter());
                    app.setApplicationStatus(updatedApplication.getApplicationStatus());
                    return applicationRepository.save(app);
                }).orElseThrow(() -> new RuntimeException("Application not found"));
    }

    public void deleteApplication(Long applicationId) {
        applicationRepository.deleteById(applicationId);
    }
}
