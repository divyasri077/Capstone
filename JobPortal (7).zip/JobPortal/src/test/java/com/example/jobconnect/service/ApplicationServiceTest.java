package com.example.jobconnect.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.example.jobconnect.exception.ResourceNotFoundException;
import com.example.jobconnect.model.Application;
import com.example.jobconnect.repository.ApplicationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class ApplicationServiceTest {

    @InjectMocks
    private ApplicationService applicationService;

    @Mock
    private ApplicationRepository applicationRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllApplications() {
        // Arrange
        List<Application> applications = new ArrayList<>();
        applications.add(new Application());
        when(applicationRepository.findAll()).thenReturn(applications);

        // Act
        List<Application> result = applicationService.getAllApplications();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(applicationRepository, times(1)).findAll(); // Verify findAll was called once
    }

    @Test
    void testGetApplicationById_Success() {
        // Arrange
        Application application = new Application();
        application.setApplicationId(1L);
        when(applicationRepository.findById(1L)).thenReturn(Optional.of(application));

        // Act
        Application result = applicationService.getApplicationById(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getApplicationId());
        verify(applicationRepository, times(1)).findById(1L); // Verify findById was called once
    }

   
}