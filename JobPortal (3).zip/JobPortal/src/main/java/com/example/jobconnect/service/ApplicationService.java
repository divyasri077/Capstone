package com.example.jobconnect.service;

import com.example.jobconnect.exception.ApplicationNotFoundException;
import com.example.jobconnect.model.Application;
import com.example.jobconnect.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    // Get all applications
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    // Get an application by ID
    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new ApplicationNotFoundException("Application not found with id: " + id));
    }

   /* // Get applications by Job ID
    public List<Application> getApplicationsByJobId(Long jobId) {
        return applicationRepository.findByJobId(jobId);
    }

    // Get applications by User ID
    public List<Application> getApplicationsByUserId(Long userId) {
        return applicationRepository.findByJobSeekerId(userId);
    } */
}
