package com.example.jobconnect.controller;

import com.example.jobconnect.exception.ResourceNotFoundException;
import com.example.jobconnect.model.Application;
import com.example.jobconnect.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/applications")
@CrossOrigin(origins = "http://localhost:4200")
@Validated
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    // Get all applications
    @GetMapping
    public List<Application> getAllApplications() {
        return applicationService.getAllApplications();
    }

    // Get an application by ID
    @GetMapping("/{id}")
    public ResponseEntity<Application> getApplicationById(@PathVariable Long id) {
        Application application = applicationService.getApplicationById(id);
        return ResponseEntity.ok(application);
    }

    // Create a new application with file uploads
    @PostMapping(consumes = "multipart/form-data")
    public ResponseEntity<Application> createApplication(
            @RequestParam("resume") MultipartFile resume,
            @RequestParam("coverLetter") MultipartFile coverLetter,
            @RequestParam("applicationStatus") String applicationStatus
    ) throws IOException {

        Application application = new Application();
        application.setApplicationStatus(applicationStatus);
        application.setResume(resume.getBytes()); // Get byte[] from the file
        application.setCoverLetter(coverLetter.getBytes()); // Get byte[] from the file
        application.setAppliedAt(java.time.LocalDateTime.now());

        Application createdApplication = applicationService.createApplication(application);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdApplication);
    }

    // Update an application
    @PutMapping("/{id}")
    public ResponseEntity<Application> updateApplication(
            @PathVariable Long id,
            @RequestParam("resume") MultipartFile resume,
            @RequestParam("coverLetter") MultipartFile coverLetter,
            @RequestParam("applicationStatus") String applicationStatus
    ) throws IOException {
        Application applicationDetails = new Application();
        applicationDetails.setResume(resume.getBytes());
        applicationDetails.setCoverLetter(coverLetter.getBytes());
        applicationDetails.setApplicationStatus(applicationStatus);

        Application updatedApplication = applicationService.updateApplication(id, applicationDetails);
        return ResponseEntity.ok(updatedApplication);
    }

    // Delete an application
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteApplication(@PathVariable Long id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.noContent().build();
    }

 /*   // Get applications by job ID
    @GetMapping("/job/{jobId}")
    public ResponseEntity<List<Application>> getApplicationsByJobId(@PathVariable Long jobId) {
        List<Application> applications = applicationService.getApplicationsByJobId(jobId);
        if (applications.isEmpty()) {
            throw new ResourceNotFoundException("No applications found for the given job ID");
        }
        return ResponseEntity.ok(applications);
    }

    // Get applications by job seeker (user) ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Application>> getApplicationsByUserId(@PathVariable Long userId) {
        List<Application> applications = applicationService.getApplicationsByUserId(userId);
        if (applications.isEmpty()) {
            throw new ResourceNotFoundException("No applications found for the given user ID");
        }
        return ResponseEntity.ok(applications);
    }  */
}
