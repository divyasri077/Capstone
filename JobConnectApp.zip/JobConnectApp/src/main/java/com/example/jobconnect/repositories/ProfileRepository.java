package com.example.jobconnect.repositories;

import com.example.jobconnect.entities.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<Profile, Long> {
}
