package com.example.jobposting.mapper;

import com.example.jobposting.dto.JobPostingDto;
import com.example.jobposting.model.JobPosting;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface JobPostingMapper {
    JobPostingMapper INSTANCE = Mappers.getMapper(JobPostingMapper.class);

    JobPostingDto jobPostingToJobPostingDto(JobPosting jobPosting);
    JobPosting jobPostingDtoToJobPosting(JobPostingDto jobPostingDto);
}
