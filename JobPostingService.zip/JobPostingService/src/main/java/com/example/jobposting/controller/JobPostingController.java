package com.example.jobposting.controller;

import com.example.jobposting.model.JobPosting;
import com.example.jobposting.service.JobPostingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/job-postings")
public class JobPostingController {

    @Autowired
    private JobPostingService jobPostingService;

    

    // Get all job postings
    @GetMapping
    public ResponseEntity<List<JobPosting>> getAllJobPostings() {
        List<JobPosting> jobPostings = jobPostingService.getAllJobPostings();
        System.out.println("Job postings fetched: " + jobPostings);
        return ResponseEntity.ok(jobPostings);
    }

    
 // Create a new job posting
    @PostMapping
    public ResponseEntity<JobPosting> createJobPosting(@RequestBody JobPosting jobPosting) {
        JobPosting createdJobPosting = jobPostingService.createJobPosting(jobPosting);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdJobPosting);
    }

    // Get a job posting by ID
    @GetMapping("/{jobId}")
    public ResponseEntity<JobPosting> getJobPostingById(@PathVariable Long jobId) {
        JobPosting jobPosting = jobPostingService.getJobPostingById(jobId);
        if (jobPosting != null) {
            return ResponseEntity.ok(jobPosting);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Update a job posting
    @PutMapping("/{jobId}")
    public ResponseEntity<JobPosting> updateJobPosting(@PathVariable Long jobId, @RequestBody JobPosting jobPostingDetails) {
        JobPosting updatedJobPosting = jobPostingService.updateJobPosting(jobId, jobPostingDetails);
        if (updatedJobPosting != null) {
            return ResponseEntity.ok(updatedJobPosting);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Delete a job posting
    @DeleteMapping("/{jobId}")
    public ResponseEntity<Void> deleteJobPosting(@PathVariable Long jobId) {
        jobPostingService.deleteJobPosting(jobId);
        return ResponseEntity.noContent().build();
    }
}
