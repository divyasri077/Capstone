package com.example.jobposting.service;

import com.example.jobposting.exception.ResourceNotFoundException;
import com.example.jobposting.model.JobPosting;
import com.example.jobposting.repository.JobPostingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

   

    // Get all job postings
    public List<JobPosting> getAllJobPostings() {
        List<JobPosting> jobPostings = jobPostingRepository.findAll();
        System.out.println("Number of job postings: " + jobPostings.size());
        return jobPostings;
    }

    
    // Create a new job posting
    public JobPosting createJobPosting(JobPosting jobPosting) {
        jobPosting.setPostedAt(LocalDateTime.now()); // Set the postedAt timestamp
        jobPosting.setUpdatedAt(LocalDateTime.now()); // Set the updatedAt timestamp
        return jobPostingRepository.save(jobPosting);
    }

    // Get a job posting by ID
    public JobPosting getJobPostingById(Long jobId) {
        return jobPostingRepository.findById(jobId)
            .orElseThrow(() -> new ResourceNotFoundException("Job posting not found with id " + jobId));
    }

    // Update a job posting
    public JobPosting updateJobPosting(Long jobId, JobPosting jobPostingDetails) {
        JobPosting jobPosting = jobPostingRepository.findById(jobId)
            .orElseThrow(() -> new ResourceNotFoundException("Job posting not found with id " + jobId));
        jobPosting.setTitle(jobPostingDetails.getTitle());
        jobPosting.setDescription(jobPostingDetails.getDescription());
        jobPosting.setLocation(jobPostingDetails.getLocation());
        jobPosting.setJobType(jobPostingDetails.getJobType());
        jobPosting.setSalaryRange(jobPostingDetails.getSalaryRange());
        jobPosting.setApplicationDeadline(jobPostingDetails.getApplicationDeadline());
        jobPosting.setUpdatedAt(LocalDateTime.now()); // Update timestamp
        return jobPostingRepository.save(jobPosting);
    }

    // Delete a job posting
    public void deleteJobPosting(Long jobId) {
        JobPosting jobPosting = jobPostingRepository.findById(jobId)
            .orElseThrow(() -> new ResourceNotFoundException("Job posting not found with id " + jobId));
        jobPostingRepository.deleteById(jobId);
    }
}