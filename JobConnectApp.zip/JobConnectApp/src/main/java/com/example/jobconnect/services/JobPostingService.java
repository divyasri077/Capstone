package com.example.jobconnect.services;

import com.example.jobconnect.entities.JobPosting;
import com.example.jobconnect.repositories.JobPostingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

    public List<JobPosting> getAllJobPostings() {
        return jobPostingRepository.findAll();
    }

    public Optional<JobPosting> getJobPostingById(Long jobId) {
        return jobPostingRepository.findById(jobId);
    }

    public JobPosting createJobPosting(JobPosting jobPosting) {
        return jobPostingRepository.save(jobPosting);
    }

    public JobPosting updateJobPosting(Long jobId, JobPosting updatedJobPosting) {
        return jobPostingRepository.findById(jobId)
                .map(job -> {
                    job.setTitle(updatedJobPosting.getTitle());
                    job.setDescription(updatedJobPosting.getDescription());
                    job.setLocation(updatedJobPosting.getLocation());
                    job.setJobType(updatedJobPosting.getJobType());
                    job.setSalaryRange(updatedJobPosting.getSalaryRange());
                    return jobPostingRepository.save(job);
                }).orElseThrow(() -> new RuntimeException("Job posting not found"));
    }

    public void deleteJobPosting(Long jobId) {
        jobPostingRepository.deleteById(jobId);
    }
}
