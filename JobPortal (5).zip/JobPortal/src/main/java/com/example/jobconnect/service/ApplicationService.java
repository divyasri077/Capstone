package com.example.jobconnect.service;

import com.example.jobconnect.exception.ResourceNotFoundException;
import com.example.jobconnect.model.Application;
import com.example.jobconnect.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    // Get all applications
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    // Get an application by ID
    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with id: " + id));
    }

    // Create a new application
    public Application createApplication(Application application) {
        // You can add additional business logic here if needed
        return applicationRepository.save(application);
    }

    // Update an existing application
    public Application updateApplication(Long id, Application applicationDetails) {
        Application application = getApplicationById(id); // fetch existing application

        application.setResume(applicationDetails.getResume());
        application.setCoverLetter(applicationDetails.getCoverLetter());
        application.setApplicationStatus(applicationDetails.getApplicationStatus());
        application.setAppliedAt(applicationDetails.getAppliedAt());

        return applicationRepository.save(application); // save the updated entity
    }

    // Delete an application
    public void deleteApplication(Long id) {
        Application application = getApplicationById(id); // ensure application exists
        applicationRepository.delete(application);
    }

  /*  // Get applications by job ID
    public List<Application> getApplicationsByJobId(Long jobId) {
        return applicationRepository.findByJobId(jobId);
    }

    // Get applications by job seeker (user) ID
    public List<Application> getApplicationsByUserId(Long userId) {
        return applicationRepository.findByUserId(userId);
    } */
}
